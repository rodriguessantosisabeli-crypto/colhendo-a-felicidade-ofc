// Jogo: Colheita Tecnológica - Agro P5.js
let ceifa;
let plantacoes = [];
let pontos = 0;
let solAngulo = 0;

function setup() {
  createCanvas(600, 400);
  
  // Inicializa a ceifa (Colheitadeira) na parte inferior da tela
  ceifa = {
    x: width / 2,
    y: 320,
    largura: 70,
    altura: 45,
    velocidade: 5
  };
  
  // Cria as primeiras plantações de trigo alinhadas no campo
  for (let i = 0; i < 10; i++) {
    gerarTrigo();
  }
}

function draw() {
  // 1. CÉU E SOL
  background('#c5e1a5'); // Céu claro de dia de colheita
  desenharSol();
  
  // 2. O CHÃO DA FAZENDA
  fill('#795548'); // Marrom da terra fértil
  noStroke();
  rect(0, 250, width, 150); 
  
  // Linhas horizontais para dar profundidade ao solo trabalhado
  stroke('#5d4037');
  strokeWeight(2);
  line(0, 290, width, 290);
  line(0, 340, width, 340);
  
  // 3. GERENCIAR E DESENHAR A PLANTAÇÃO
  for (let i = plantacoes.length - 1; i >= 0; i--) {
    let trigo = plantacoes[i];
    
    // O trigo cresce ligeiramente com o tempo se não foi colhido
    if (trigo.tamanho < 35) {
      trigo.tamanho += 0.05;
    }
    
    desenharTrigo(trigo.x, trigo.y, trigo.tamanho);
    
    // Verifica se a ceifa (barra de corte frontal) passou pelo trigo
    if (verificarColisaoCeifa(ceifa, trigo)) {
      pontos += 10;
      plantacoes.splice(i, 1); // Remove o trigo colhido
      gerarTrigo(); // Nasce um novo trigo em ponto aleatório do campo
    }
  }
  
  // 4. CONTROLE DA CEIFA PELAS SETAS
  moverCeifa();
  
  // 5. DESENHAR A CEIFA (Colheitadeira)
  desenharColheitadeira(ceifa.x, ceifa.y);
  
  // 6. INTERFACE DE PONTOS (HUD)
  desenharPainel();
}

function moverCeifa() {
  // Movimentação livre em todas as direções usando as Setas do Teclado
  if (keyIsDown(LEFT_ARROW))  ceifa.x -= ceifa.velocidade;
  if (keyIsDown(RIGHT_ARROW)) ceifa.x += ceifa.velocidade;
  if (keyIsDown(UP_ARROW))    ceifa.y -= ceifa.velocidade;
  if (keyIsDown(DOWN_ARROW))  ceifa.y += ceifa.velocidade;
  
  // Limita os movimentos da ceifa para operar apenas dentro do chão/campo
  ceifa.x = constrain(ceifa.x, ceifa.largura / 2, width - ceifa.largura / 2);
  ceifa.y = constrain(ceifa.y, 260, height - ceifa.altura);
}

function desenharSol() {
  push();
  // Movimento sutil nos raios do sol usando seno
  solAngulo += 0.02;
  let tamanhoRaio = 70 + sin(solAngulo) * 4;
  
  // Brilho externo do sol
  fill(255, 235, 59, 150);
  noStroke();
  circle(100, 80, tamanhoRaio);
  
  // Núcleo do sol
  fill('#ffeb3b');
  circle(100, 80, 55);
  pop();
}

function gerarTrigo() {
  plantacoes.push({
    x: random(40, width - 40),
    y: random(270, 370), // Espalhados pelo chão de terra
    tamanho: random(15, 25) // Começam com tamanhos variados
  });
}

function desenharTrigo(x, y, tam) {
  push();
  stroke('#fbc02d'); // Amarelo ouro do trigo maduro
  strokeWeight(3);
  // Caule principal
  line(x, y, x, y - tam);
  
  // Ramos superiores do trigo (grãos)
  strokeWeight(2);
  line(x, y - tam, x - 5, y - tam - 5);
  line(x, y - tam, x + 5, y - tam - 5);
  line(x, y - tam + 6, x - 4, y - tam + 1);
  line(x, y - tam + 6, x + 4, y - tam + 1);
  pop();
}

function desenharColheitadeira(x, y) {
  push();
  rectMode(CENTER);
  
  // Rodas pretas reforçadas
  fill(40);
  noStroke();
  rect(x - 22, y + 12, 14, 22, 4);
  rect(x + 22, y + 12, 14, 22, 4);
  
  // Chassi/Corpo principal da máquina agrícola (Verde Agro)
  fill('#2e7d32');
  stroke('#1b5e20');
  strokeWeight(2);
  rect(x, y, ceifa.largura, ceifa.altura, 6);
  
  // Cabine de vidro do operador
  fill('#e0f7fa');
  stroke('#b2ebf2');
  rect(x, y - 8, ceifa.largura - 24, ceifa.altura - 20, 3);
  
  // Plataforma de corte frontal (A Ceifa amarela que recolhe o trigo)
  fill('#fbc02d');
  stroke('#f57f17');
  rect(x, y - ceifa.altura / 2 - 4, ceifa.largura + 10, 8, 2);
  
  // Detalhes dos dentes da barra de corte
  stroke('#f57f17');
  for (let i = -ceifa.largura/2; i <= ceifa.largura/2; i += 10) {
    line(x + i, y - ceifa.altura/2 - 4, x + i, y - ceifa.altura/2 - 10);
  }
  pop();
}

function verificarColisaoCeifa(c, t) {
  // A colisão é calculada com base na barra de corte frontal da máquina
  let ceifaFrenteY = c.y - c.altura / 2 - 6;
  let distanciaX = abs(c.x - t.x);
  
  // Verifica se o trigo está alinhado com a largura da barra e na altura correta de corte
  return (distanciaX < (c.largura / 2 + 10) && t.y - t.tamanho <= c.y + 10 && t.y >= ceifaFrenteY - 15);
}

function desenharPainel() {
  // Faixa superior do painel
  fill(0, 100);
  noStroke();
  rect(0, 0, width, 45);
  
  // Texto descritivo
  fill(255);
  textSize(16);
  textAlign(LEFT, CENTER);
  text("🌾 Safra Tecnológica", 20, 22);
  
  textAlign(RIGHT, CENTER);
  text("Produção Coletada: " + pontos + " kg", width - 20, 22);
}
